import grpc

from umg import umg_pb2, umg_pb2_grpc


class Auth:
    def __init__(self, url: str = None, ssl: bool = False):
        self.url = url
        self.ssl = ssl

    def set_url(self, url: str):
        self.url = url

    def enable_ssl(self):
        self.ssl = true

    def disable_ssl(self):
        self.ssl = false

    def has_dom_perm(self, token, domain, action, building):
        channel, stub = self.__new_channel()

        try:
            req = umg_pb2.DomainPermRequest()
            req.token = token
            req.domain = domain
            req.action = action
            req.building = building

            res = stub.HasDomainPerm(req)
            return res.OK
        except Exception as e:
            print("error while checking domain permission \n", e)
        finally:
            channel.close()

        return False

    def has_prod_perm(self, token, domain, product, action, building):
        channel, stub = self.__new_channel()

        try:
            req = umg_pb2.ProductPermRequest()
            req.token = token
            req.domain = domain
            req.product = product
            req.action = action
            req.building = building

            res = stub.HasProductPerm(req)
            return res.OK
        except Exception as e:
            print("error while checking product permission \n", e)
        finally:
            channel.close()

        return False

    def is_admin(self, token):
        channel, stub = self.__new_channel()

        try:
            req = umg_pb2.IsAdminRequest()
            req.token = token

            res = stub.IsAdmin(req)
            return res.OK
        except Exception as e:
            print("error while checking admin permission \n", e)
        finally:
            channel.close()

        return False

    def is_valid_building(self, building_id):
        channel, stub = self.__new_channel()

        try:
            req = umg_pb2.IsValidBuildingRequest()
            req.id = building_id

            res = stub.IsValidBuilding(req)
            return res.OK
        except Exception as e:
            print("error while validating building \n", e)
        finally:
            channel.close()

        return False

    def __new_channel(self):
        if self.ssl:
            return self.__new_secure_channel()

        return self.__new_insecure_chanel()

    def __new_secure_channel(self):
        credentials = grpc.ssl_channel_credentials(root_certificates=None, private_key=None, certificate_chain=None)
        channel = grpc.secure_channel(self.url, credentials)
        stub = umg_pb2_grpc.AuthServiceStub(channel)

        return channel, stub

    def __new_insecure_chanel(self):
        channel = grpc.insecure_channel(self.url)
        stub = umg_pb2_grpc.AuthServiceStub(channel)

        return channel, stub
