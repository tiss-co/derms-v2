import grpc

from umg import umg_pb2, umg_pb2_grpc

__url = 'api.edgecomenergy.ca:50054'


def set_url(url):
    global __url

    __url = url


def get_url():
    return __url


def has_dom_perm(token, domain, action, building):
    channel = grpc.insecure_channel(__url)
    stub = umg_pb2_grpc.AuthServiceStub(channel)

    try:
        req = umg_pb2.DomainPermRequest()
        req.token = token
        req.domain = domain
        req.action = action
        req.building = building

        res = stub.HasDomainPerm(req)
        return res.OK
    except Exception as e:
        print("error while checking domain permission \n", e)
    finally:
        channel.close()

    return False


def has_prod_perm(token, domain, product, action, building):
    channel = grpc.insecure_channel(__url)
    stub = umg_pb2_grpc.AuthServiceStub(channel)

    try:
        req = umg_pb2.ProductPermRequest()
        req.token = token
        req.domain = domain
        req.product = product
        req.action = action
        req.building = building

        res = stub.HasProductPerm(req)
        return res.OK
    except Exception as e:
        print("error while checking product permission \n", e)
    finally:
        channel.close()

    return False


def is_admin(token):
    channel = grpc.insecure_channel(__url)
    stub = umg_pb2_grpc.AuthServiceStub(channel)

    try:
        req = umg_pb2.IsAdminRequest()
        req.token = token

        res = stub.IsAdmin(req)
        return res.OK
    except Exception as e:
        print("error while checking admin permission \n", e)
    finally:
        channel.close()

    return False


def is_valid_building(building_id):
    channel = grpc.insecure_channel(__url)
    stub = umg_pb2_grpc.AuthServiceStub(channel)

    try:
        req = umg_pb2.IsValidBuildingRequest()
        req.id = building_id

        res = stub.IsValidBuilding(req)
        return res.OK
    except Exception as e:
        print("error while validating building \n", e)
    finally:
        channel.close()

    return False
